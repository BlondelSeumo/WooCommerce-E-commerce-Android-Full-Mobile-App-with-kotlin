<?php
/*
 * key Options
 */
$app_opt_name;

Redux::setSection( $app_opt_name, array(
    'title' => esc_html__( 'Social Links', 'iqonic' ),
    'id'    => 'social_link',
    'icon'  => 'el el-link',
    'subsection' => false,
    'desc'  => esc_html__( '', 'iqonic' ),
    'fields'           => array(
        array(
            'id'        => 'whatsapp',
            'type'      => 'text',
            'title'     => esc_html__( 'WhatsApp','iqonic'),  
            'desc'      => __('<b>Please Enter Number With Country Code</b><p><i>For e.g. <b>919876543210</b></i></p><p><b>91</b> Is Country Code</p>'),         
            'validate' => 'numeric'
        ),

        array(
            'id'        => 'facebook',
            'type'      => 'text',
            'title'     => esc_html__( 'Facebook','iqonic'),       
            'validate' => 'url'    
            
        ),

        array(
            'id'        => 'twitter',
            'type'      => 'text',
            'title'     => esc_html__( 'twitter','iqonic'),   
            'validate' => 'url'        
        ),

        array(
            'id'        => 'instagram',
            'type'      => 'text',
            'title'     => esc_html__( 'Instagram','iqonic'),  
            'validate' => 'url'          
        ),

        array(
            'id'        => 'contact',
            'type'      => 'text',
            'title'     => esc_html__( 'Customer Care Number','iqonic'),    
            'validate' => 'numeric'        
        ),

        array(
            'id'        => 'privacy_policy',
            'type'      => 'text',
            'title'     => esc_html__( 'Privacy Policy Url','iqonic'),  
            'validate' => 'url'          
        ),

        array(
            'id'        => 'term_condition',
            'type'      => 'text',
            'title'     => esc_html__( 'Term & Condition Url','iqonic'),  
            'validate' => 'url'          
        ),

        array(
            'id'        => 'copyright_text',
            'type'      => 'textarea',
            'title'     => esc_html__( 'Copyright Text','iqonic'), 
        ),    
    )

));