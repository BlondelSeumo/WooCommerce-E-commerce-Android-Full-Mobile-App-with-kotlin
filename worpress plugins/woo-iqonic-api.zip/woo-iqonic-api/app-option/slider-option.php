<?php
/*
 * slider Options
 */
$app_opt_name;



// Redux::setSection( $app_opt_name, array(
//     'title' => esc_html__( 'Upload Slider Images', 'iqonic' ),
//     'id'    => 'iqonic',
//     'icon'  => 'el el-slideshare',
//     'subsection' => false,
//     'desc'  => esc_html__( '', 'iqonic' ),
//     'fields'           => array(
        
//         array(
//             'id'          => 'opt-slides',
//             'type'        => 'slides',
//             'title'       => __('Slides', 'iqonic'),   
//             'show' => array(
//                 'title' => false,
//                 'description' => false,
//                 'url' => true              
//             ),         
//             'placeholder' => array(
//                 'title'           => __('This is a title', 'iqonic'),
                
//             ),
//         ),
                    
//     )
    
// ) );

Redux::setSection( $app_opt_name, array(
    'title' => esc_html__( 'Global', 'iqonic' ),
    'id'    => 'iqonic-theme-color',
    'icon'  => 'el el-brush',
    'subsection' => false,
    'desc'  => esc_html__( 'Select Your App Theme Color Here', 'iqonic' ),
    'fields'           => array(
        
        // array(
        //     'id'          => 'iqonic_app_primary_color',
        //     'type'        => 'color',
        //     'transparent' => false,
        //     'title'       => __('Primary Color', 'iqonic'),   
        //     'desc' => __('Choose App Theme Color Here', 'iqonic'),
                    
          
        // ),

        //  array(
        //     'id'          => 'iqonic_app_secondary_color',
        //     'type'        => 'color',
        //     'transparent' => false,
        //     'title'       => __('Secondary Color', 'iqonic'),   
        //     'desc' => __('Choose App Theme Color Here', 'iqonic'),                    
           
        // ),

         array(
                'id'       => 'iqonic_app_lang',
                'type'     => 'select',
                'title'    => __('Select App Language', 'iqonic'),                 
                'options'  => array(
                    'en' => 'English',
                    'hi' => 'Hindi',
                    'fr' => 'French',
                    'es' => 'Spanish',
                    'de' => 'German',
                    'in' => 'Indonesian',
                    'af' => 'Afrikaans',
                    'pt' => 'Portuguese',
                    'tr' => 'Turkish',
                    'ar' => 'Arabic',
                    'vi' => 'Vietnamese',                    
                ),
                'default'  => 'en',
        ),

         array(
                'id'       => 'iqonic_payment_method',
                'type'     => 'select',
                'title'    => __('Select Payment Method', 'iqonic'),                 
                'options'  => array(
                    'native' => 'Native',
                    'webview' => 'WebView',
                    
                ),
                'default'  => 'webview',
        )
                    
    )
    
) );

Redux::setSection( $app_opt_name, array(
    'title' => esc_html__( 'Advertisement Images', 'iqonic' ),
    'id'    => 'banner',
    'icon'  => 'el el-slideshare',
    'subsection' => false,
    'desc'  => esc_html__( '', 'iqonic' ),
    'fields'           => array(
        
        array(
            'id'          => 'banner_slider',
            'type'        => 'slides',
            'title'       => __('Advertisement Images', 'iqonic'),   
            'show' => array(
                'title' => true,
                'description' => false,
                'url' => true              
            ),         
            'placeholder' => array(
                'title'           => __('This is a title', 'iqonic'),
                
            ),
        ),
                    
    )
    
) );