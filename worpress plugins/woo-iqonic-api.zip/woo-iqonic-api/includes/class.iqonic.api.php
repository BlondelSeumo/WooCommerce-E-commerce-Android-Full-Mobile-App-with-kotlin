<?php
class iqonic_Api
{
    private $plugin_name, $version;
    public function __construct()
    {
        $this->plugin_name = 'iqonic-api';
        $this->version = '1.0';
        $this->load_dependancies();
        $this->set_locale();
    }

    private function load_dependancies()
    {

        require_once IQONIC_API_DIR . 'includes/api/helperfunction/helperfunction.php';


        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.authentication.php';
        require_once IQONIC_API_DIR . 'includes/db/class.iqonic.db.php';
        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.wishlist.route.php';
        require_once IQONIC_API_DIR . 'includes/class-iqonic-api-i18n.php';
        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.cart.route.php';
        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.slider.route.php';
        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.woocommerce.route.php';
        require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.customer.route.php';
        

       // require_once IQONIC_API_DIR . 'includes/api/v1/class.iqonic.api.payment.route.php';

       
        require_once IQONIC_API_DIR . 'includes/ajax/class.iqonic.request_ajax.php';
        
        require_once IQONIC_API_DIR . 'includes/notification/class.sendnotification.php';

        require_once IQONIC_API_DIR . 'includes/custom-filed_wc/iqonic_custom_filed_wc.php';
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the iqonic_Api_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     */
    private function set_locale()
    {
        // $plugin_i18n = new iqonic_Api_i18n();
        // $plugin_i18n->set_domain($this->get_plugin_name());
        // add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
        
    }

    public function get_plugin_name()
    {
        return $this->plugin_name;
    }
}
?>